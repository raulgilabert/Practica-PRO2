var searchData=
[
  ['read_0',['read',['../class_set__categories.html#a2d84f4d1299b68c3aa70425ad30a97ce',1,'Set_categories::read()'],['../class_set__players.html#a6206ccc73a63eb2e64719333d8e409f8',1,'Set_players::read()'],['../class_set__tournament.html#a0000bd1ed7584e9261ef5026c8ac50ae',1,'Set_tournament::read()']]],
  ['recalculate_5franking_1',['recalculate_ranking',['../class_set__players.html#a6fb442d27e5b8f70ea4f4cd1741a338b',1,'Set_players']]],
  ['result_5ftournament_2',['result_tournament',['../class_tournament.html#adba6ef8314f6b904fe22a20eb724b14c',1,'Tournament']]]
];

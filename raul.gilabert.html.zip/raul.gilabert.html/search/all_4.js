var searchData=
[
  ['games_5flost_0',['games_lost',['../class_player.html#ad015df8ddda23ab315a4d3bc3b576e1f',1,'Player']]],
  ['games_5fwon_1',['games_won',['../class_player.html#a17f0f9497a689695d342acb4928a654d',1,'Player']]],
  ['get_5fcategories_2',['get_categories',['../class_set__categories.html#af0caa3e768ec0294a9953ce7b5e8a72b',1,'Set_categories']]],
  ['get_5fcategory_3',['get_category',['../class_tournament.html#a4648690ed8b2360f09468922d54e11d5',1,'Tournament']]],
  ['get_5fname_4',['get_name',['../class_category.html#a91eb21a6a04917e96f20c90c1956f809',1,'Category']]],
  ['get_5fplayer_5',['get_player',['../class_set__players.html#a7bb08bb503c270caf51076500d212d69',1,'Set_players']]],
  ['get_5fplayers_6',['get_players',['../class_set__players.html#ada5b3b0de2bf3c89d44cd9a75a3489ca',1,'Set_players']]],
  ['get_5fpoints_7',['get_points',['../class_player.html#ab23a648d916e68452049de0d3709f5d2',1,'Player']]],
  ['get_5fpoints_5fper_5flevel_8',['get_points_per_level',['../class_category.html#ace6dc37f4d0a839fa102d341aef7b3c5',1,'Category']]],
  ['get_5franking_9',['get_ranking',['../class_set__players.html#ab44d75b687a163b06d18b753d71a7fda',1,'Set_players']]],
  ['get_5ftournament_10',['get_tournament',['../class_set__tournament.html#ac501b54bfa79ad6ce5b0a6b8913606ef',1,'Set_tournament']]],
  ['get_5ftournaments_11',['get_tournaments',['../class_set__tournament.html#a9e5dfeaaf0cd487311d18c9171c04e87',1,'Set_tournament']]]
];

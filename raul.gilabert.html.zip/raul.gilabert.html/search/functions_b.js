var searchData=
[
  ['update_5fdata_0',['update_data',['../class_player.html#aacd0bdb6d7c38196e0b8e38b5b6af4cd',1,'Player']]]
];

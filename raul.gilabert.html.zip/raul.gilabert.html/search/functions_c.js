var searchData=
[
  ['_7ecategory_0',['~Category',['../class_category.html#aaa98d8419b1d26679a01713ac8fe58dc',1,'Category']]],
  ['_7eplayer_1',['~Player',['../class_player.html#a749d2c00e1fe0f5c2746f7505a58c062',1,'Player']]],
  ['_7eset_5fcategories_2',['~Set_categories',['../class_set__categories.html#aee9357b2ca34b4c6e1a4f7799978756e',1,'Set_categories']]],
  ['_7eset_5fplayers_3',['~Set_players',['../class_set__players.html#aa018f32a79c942d628451327d3af9d63',1,'Set_players']]],
  ['_7eset_5ftournament_4',['~Set_tournament',['../class_set__tournament.html#a1280f0f825163a1b8a9e6c2bd9ac9719',1,'Set_tournament']]],
  ['_7etournament_5',['~Tournament',['../class_tournament.html#a3cd15abb3e9599c60ae124fed5a04ee5',1,'Tournament']]]
];

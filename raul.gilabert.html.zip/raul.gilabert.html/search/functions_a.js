var searchData=
[
  ['tournament_0',['Tournament',['../class_tournament.html#aa31684f469ee8ecb4e750a31db9ffa41',1,'Tournament']]],
  ['tournament_5fexists_1',['tournament_exists',['../class_set__tournament.html#a9730a7b500bc38a77c06f059eb975aae',1,'Set_tournament']]]
];

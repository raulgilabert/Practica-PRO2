var searchData=
[
  ['add_5fcategory_0',['add_category',['../class_set__categories.html#aa2f5376f08ed1aea1e7bcdd0bb91b369',1,'Set_categories']]],
  ['add_5fplayer_1',['add_player',['../class_set__players.html#af7296ec7b05e7249a78fba1c0ac9749e',1,'Set_players::add_player()'],['../class_tournament.html#a650798aadb454b8727b35e9e3ddacd39',1,'Tournament::add_player()']]],
  ['add_5ftournament_2',['add_tournament',['../class_category.html#a8c68999b0b2acc15f0227f3aa8a9f12f',1,'Category::add_tournament()'],['../class_player.html#a28864b044b23ceb997fd6295e1ad517e',1,'Player::add_tournament()'],['../class_set__categories.html#a5eb642f11f855c5748165f0bdd1c5709',1,'Set_categories::add_tournament()'],['../class_set__players.html#a9f4964e210cda1754b42c2ccb2d3f7ae',1,'Set_players::add_tournament()'],['../class_set__tournament.html#add434cafb41f4b8e9b27a01049865e08',1,'Set_tournament::add_tournament()']]]
];

var searchData=
[
  ['set_5fcategories_0',['Set_categories',['../class_set__categories.html#a7f6e57b042346e078ff5401aa7647049',1,'Set_categories']]],
  ['set_5fplayers_1',['Set_players',['../class_set__players.html#a64027e9a89abdb8def809626d00f54bc',1,'Set_players']]],
  ['set_5fpoints_5fper_5flevel_2',['set_points_per_level',['../class_category.html#ab5a8b1735b996ae048b495687ec72ceb',1,'Category']]],
  ['set_5ftournament_3',['Set_tournament',['../class_set__tournament.html#a72862828246c9a2c0916934be11f7302',1,'Set_tournament']]],
  ['sort_5fplayers_4',['sort_players',['../class_set__players.html#aeb1588e4acc0115745140420ffe2aba2',1,'Set_players']]],
  ['sort_5ftournaments_5',['sort_tournaments',['../class_set__tournament.html#abd4a4795512abdba3dfafc490ad740c6',1,'Set_tournament']]]
];

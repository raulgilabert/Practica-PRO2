var searchData=
[
  ['ranking_0',['ranking',['../class_set__players.html#ad4640eb2de0b542e8bc86eb5cef626d0',1,'Set_players']]],
  ['ranking_5fposition_1',['ranking_position',['../class_player.html#aa3d611ebcf0b9e7b403116295340ce00',1,'Player']]],
  ['read_2',['read',['../class_set__categories.html#a2d84f4d1299b68c3aa70425ad30a97ce',1,'Set_categories::read()'],['../class_set__players.html#a6206ccc73a63eb2e64719333d8e409f8',1,'Set_players::read()'],['../class_set__tournament.html#a0000bd1ed7584e9261ef5026c8ac50ae',1,'Set_tournament::read()']]],
  ['recalculate_5franking_3',['recalculate_ranking',['../class_set__players.html#a6fb442d27e5b8f70ea4f4cd1741a338b',1,'Set_players']]],
  ['result_5ftournament_4',['result_tournament',['../class_tournament.html#adba6ef8314f6b904fe22a20eb724b14c',1,'Tournament']]]
];

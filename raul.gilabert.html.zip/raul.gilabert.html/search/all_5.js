var searchData=
[
  ['id_0',['id',['../class_category.html#a1194fc6afc84589ce499c1612cd97185',1,'Category::id()'],['../class_tournament.html#a8d5a69afdfcd948e7d045bcd38fa94f4',1,'Tournament::id()']]]
];

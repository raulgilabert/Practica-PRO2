var searchData=
[
  ['players_0',['players',['../class_set__players.html#a0eb3cdc811ffbe32af45050bd268619b',1,'Set_players::players()'],['../class_tournament.html#a770ac33380e96369af02c00575c38466',1,'Tournament::players()']]],
  ['players_5fdata_1',['players_data',['../class_set__players.html#a2600e1d82effcdeb6ed500d9dc3b2d39',1,'Set_players']]],
  ['points_2',['points',['../class_player.html#adf0398ea8c1f29175204508ab642b64e',1,'Player']]],
  ['points_5fper_5flevel_3',['points_per_level',['../class_category.html#adbb7e81eb516272e9e000e3f8a8790e9',1,'Category']]],
  ['points_5fper_5ftournament_4',['points_per_tournament',['../class_player.html#a4117303db3022ea570530b5fb16f0d83',1,'Player']]]
];

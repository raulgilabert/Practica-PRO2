var searchData=
[
  ['calc_5fpoints_0',['calc_points',['../class_player.html#a1fad3d0fd7e8209ec29cb60b16d48ba2',1,'Player']]],
  ['category_1',['Category',['../class_category.html#a02562067b26e17dfd56f5a616183be30',1,'Category']]]
];

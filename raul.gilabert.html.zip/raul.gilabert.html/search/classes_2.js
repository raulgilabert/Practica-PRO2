var searchData=
[
  ['set_5fcategories_0',['Set_categories',['../class_set__categories.html',1,'']]],
  ['set_5fplayers_1',['Set_players',['../class_set__players.html',1,'']]],
  ['set_5ftournament_2',['Set_tournament',['../class_set__tournament.html',1,'']]]
];

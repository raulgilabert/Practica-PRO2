var indexSectionsWithContent =
{
  0: "acdegilmnprstu~",
  1: "cpst",
  2: "cmpst",
  3: "acdegmnprstu~",
  4: "cgilmnprst",
  5: "p"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Pages"
};


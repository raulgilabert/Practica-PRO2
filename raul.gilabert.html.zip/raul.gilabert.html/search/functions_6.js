var searchData=
[
  ['num_5fcategories_0',['num_categories',['../class_set__categories.html#a009e2c0ff6358700dc8b0060173774b3',1,'Set_categories']]],
  ['num_5ftournaments_1',['num_tournaments',['../class_set__tournament.html#af00c9ce9cb2d489a0c7b0db9b8e795a9',1,'Set_tournament']]]
];

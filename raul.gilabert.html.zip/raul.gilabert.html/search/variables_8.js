var searchData=
[
  ['sets_5flost_0',['sets_lost',['../class_player.html#a904c73bbbbe8be6ca9022eb316619c78',1,'Player']]],
  ['sets_5fwon_1',['sets_won',['../class_player.html#a4a51f0af5e3f896ce8ee238c6085ac70',1,'Player']]]
];

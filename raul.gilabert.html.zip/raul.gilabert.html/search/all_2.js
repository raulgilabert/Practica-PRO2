var searchData=
[
  ['delete_5fplayer_0',['delete_player',['../class_set__players.html#ad8e83d08b44ab8c604b48bbfd5cb463a',1,'Set_players']]],
  ['delete_5ftournament_1',['delete_tournament',['../class_category.html#aac0d6a0de2c616f5fb15c1833b984016',1,'Category::delete_tournament()'],['../class_player.html#ae07540cc4d29f55a9f9569b46d29abe8',1,'Player::delete_tournament()'],['../class_set__categories.html#a4a25f0d50b4a12225e47858d9b44722e',1,'Set_categories::delete_tournament()'],['../class_set__players.html#a4336e4e19553a4de7370836678c30fc8',1,'Set_players::delete_tournament()'],['../class_set__tournament.html#ac680fc11b56d376995a719b9bc94dc3d',1,'Set_tournament::delete_tournament()']]]
];

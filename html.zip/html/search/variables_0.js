var searchData=
[
  ['categories_0',['categories',['../class_set__categories.html#a4bba343807dfb17a91677fc3b2b5134b',1,'Set_categories']]],
  ['category_1',['category',['../class_tournament.html#afe0ad181e8c5b1feb708dc4f07d90651',1,'Tournament']]]
];

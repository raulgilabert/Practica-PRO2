var searchData=
[
  ['end_5ftournament_0',['end_tournament',['../class_tournament.html#a688e014acbbd375f57f816dc3334e35d',1,'Tournament']]]
];

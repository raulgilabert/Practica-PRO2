var searchData=
[
  ['main_0',['main',['../main_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'main.cc']]],
  ['main_2ecc_1',['main.cc',['../main_8cc.html',1,'']]],
  ['matches_2',['matches',['../class_tournament.html#a0878527032dd63e7b3e46cdedc1bd555',1,'Tournament']]]
];

var searchData=
[
  ['levels_0',['levels',['../class_set__categories.html#adc230f54da93c51d285626a75d0ef369',1,'Set_categories']]]
];

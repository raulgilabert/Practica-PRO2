var searchData=
[
  ['ranking_0',['ranking',['../class_set__players.html#ad4640eb2de0b542e8bc86eb5cef626d0',1,'Set_players']]],
  ['ranking_5fposition_1',['ranking_position',['../class_player.html#aa3d611ebcf0b9e7b403116295340ce00',1,'Player']]]
];

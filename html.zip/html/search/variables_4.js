var searchData=
[
  ['matches_0',['matches',['../class_tournament.html#a0878527032dd63e7b3e46cdedc1bd555',1,'Tournament']]]
];

var searchData=
[
  ['name_0',['name',['../class_player.html#acf0355128a99ee20ad9931b760fb2de1',1,'Player']]],
  ['num_1',['num',['../class_set__categories.html#a4d2a30504e037b29137bff833a4cf01c',1,'Set_categories::num()'],['../class_set__players.html#a15e63a6a62a79ca94fc1efc2bcd5a588',1,'Set_players::num()']]],
  ['num_5fregistered_2',['num_registered',['../class_tournament.html#a0c15a5159c624c627cec923d12314940',1,'Tournament']]],
  ['number_3',['number',['../class_set__tournament.html#a576422eab3d1662b25fc9c9ea93e18d1',1,'Set_tournament']]]
];

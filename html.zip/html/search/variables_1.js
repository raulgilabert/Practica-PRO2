var searchData=
[
  ['games_5flost_0',['games_lost',['../class_player.html#ad015df8ddda23ab315a4d3bc3b576e1f',1,'Player']]],
  ['games_5fwon_1',['games_won',['../class_player.html#a17f0f9497a689695d342acb4928a654d',1,'Player']]]
];
